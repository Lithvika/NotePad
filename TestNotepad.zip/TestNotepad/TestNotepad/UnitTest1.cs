﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Windows;
using System;
using System.Threading;

namespace TestNotepad
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()



        {
            System.Diagnostics.Process.Start(@"C:\Program Files (x86)\Windows Application Driver\WinAppDriver.exe");
            AppiumOptions options = new AppiumOptions();
            options.AddAdditionalCapability("app", @"C:\Windows\notepad.exe");
            //options.AddAdditionalCapability("devicename", "windowspc");
            var driver = new WindowsDriver<WindowsElement>(new Uri("http://127.0.0.1:4723"),options);

            WindowsElement notepadWindow = driver.FindElementByClassName("Notepad");

            // Type some text into Notepad
            notepadWindow.SendKeys("Hello, this is automated text!");



             driver.CloseApp();

        }
    }
}
