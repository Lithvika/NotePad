﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium.Appium.Windows;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium;
using System;
using OpenQA.Selenium.Remote;
using NUnit.Framework;

namespace TestNotepad
{
    [TestClass]
    public class NotepadTest
    {

        private WindowsDriver<WindowsElement> driver;

        [SetUp]
        public void Setup()
        {
            // DesiredCapabilities appCapabilities = new DesiredCapabilities();
            //appCapabilities.SetCapability("app", "C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Accessories");
            System.Diagnostics.Process.Start(@"C:\Program Files (x86)\Windows Application Driver\WinAppDriver.exe");
            AppiumOptions options = new AppiumOptions();
            options.AddAdditionalCapability("app", @"C:\Windows\notepad.exe");
            //options.AddAdditionalCapability("devicename", "windowspc");
            var driver = new WindowsDriver<WindowsElement>(new Uri("http://127.0.0.1:4723"), options);

           // driver = new WindowsDriver<WindowsElement>(new Uri("http://127.0.0.1:4723"), options);
            //NUnit.Framework.Assert.IsNotNull(driver);
        }

        [Test]
        public void TestNotepad()
        {
            WindowsElement editor = driver.FindElementByClassName("Edit");

            // Type "Hello World"
            editor.SendKeys("Hello World");

            // Save the file
            driver.FindElementByName("File").Click();
            driver.FindElementByName("Save As...").Click();
            driver.FindElementByName("File name:").SendKeys("First Test");
            driver.FindElementByName("Save").Click();

            // Re-open the file
            driver.FindElementByName("File").Click();
            driver.FindElementByName("Open...").Click();
            driver.FindElementByName("File name:").SendKeys("First Test");
            driver.FindElementByName("Open").Click();

            // Re-edit the file name
            editor = driver.FindElementByClassName("Edit");
            editor.Clear();
            editor.SendKeys("First Task");

            // Add assertions here if needed
        }

        [TearDown]
        public void TearDown()
        {
            driver.Quit();
        }
    }
}
